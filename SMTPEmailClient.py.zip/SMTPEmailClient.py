import socket
import base64
import os

FORMAT = "utf8"
SERVER_PORT = 2225

msg = "\r\n I love computer networks!"
endmsg = "\r\n.\r\n"
# Choose a mail server (e.g., Google mail server) and call it mailserver
mailserver = '127.0.0.1'
# Create a socket called clientSocket and establish a TCP connection with mailserver
clientSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
clientSocket.connect((mailserver, SERVER_PORT))

recv = clientSocket.recv(1024).decode()
print(recv)
if recv[:3] != '220':
    print('220 reply not received from server.')

# Send HELO command and print server response.
heloCommand = 'EHLO [127.0.0.1]\r\n'
clientSocket.send(heloCommand.encode(FORMAT))
recv1 = clientSocket.recv(1024).decode()
print(recv1)

if recv1[:3] != '250':
    print('250 reply not received from server.')

# Send STARTTLS command if needed (uncomment the following lines if required)
# clientSocket.send(b'STARTTLS\r\n')
# recv_tls = clientSocket.recv(1024).decode()
# print(recv_tls)

# Add authentication if required
# username = 'your_username'
# password = 'your_password'
# clientSocket.send(f'AUTH LOGIN {base64.b64encode(username.encode()).decode()}\r\n'.encode(FORMAT))
# recv_auth_username = clientSocket.recv(1024).decode()
# print(recv_auth_username)
# clientSocket.send(f'{base64.b64encode(password.encode()).decode()}\r\n'.encode(FORMAT))
# recv_auth_password = clientSocket.recv(1024).decode()
# print(recv_auth_password)

# Send MAIL FROM command and print server response.
send = 'MAIL FROM:<baomun221@gmail.com>\r\n'
clientSocket.send(send.encode(FORMAT))
recv = clientSocket.recv(1024).decode()
print(recv)

if recv[:3] != '250':
    print('250 reply not received from the server.')

# Prepare email accounts:
email_accounts = ['baomun221@gmail.com', 'vantai327@gmail.com']

# Prepare email data:
sender = email_accounts[0]
recipient_To = email_accounts[1]
subject = 'New EMAIL'
message = 'THIS IS A TEST EMAIL'

# Initialize the email status
email_status = {'sent': False, 'read': False}

def gui_TO(recipient):
    send = f'RCPT TO:<{recipient}>\r\n'
    clientSocket.send(send.encode(FORMAT))
    recv = clientSocket.recv(1024).decode()
    print(recv)

    send = 'DATA\r\n'
    clientSocket.send(send.encode(FORMAT))
    recv = clientSocket.recv(1024).decode()
    print(recv)

    if recv[:3] != '354':
        print('354 reply not received from the server')

    # Send email data:
    clientSocket.send(b'To:' + recipient.encode(FORMAT) + b'\r\n')
    clientSocket.send(b'From:' + sender.encode(FORMAT) + b'\r\n')
    clientSocket.send(b'Subject:' + subject.encode(FORMAT) + b'\r\n')
    clientSocket.send(b'Content-Type:text/plain;charset=UTF-8;format=flowed' + b'\r\n')
    clientSocket.send(b'\r\n')  # Blank line separating header and email body

    clientSocket.send(message.encode(FORMAT) + b'\r\n')
    # Message ends with a single period.
    clientSocket.send(b'.\r\n')
    recv = clientSocket.recv(1024).decode()
    print(recv)

    # Set the email status to 'sent' after sending
    email_status['sent'] = True

    # Lưu trạng thái đã đọc vào tập tin
    with open('read_status.txt', 'w') as file:
        file.write('read')

    # Send QUIT command and get server response.
    clientSocket.send(b'QUIT\r\n')
    recv_quit = clientSocket.recv(1024).decode()
    print(recv_quit)

# Check if the email has been sent successfully
if email_status['sent']:
    print(f"Email has been sent to {recipient_To}")

    # Gọi hàm gui_TO để gửi email và xử lý trạng thái đã đọc
    gui_TO(recipient_To)

    # Kiểm tra tập tin trạng thái đã đọc
    if os.path.exists('read_status.txt'):
        print(f"The email has been read by {recipient_To}")
        email_status['read'] = True
    else:
        print(f"The email has not been read by {recipient_To}")

    # You can add more code here to handle actions when the email is read
else:
    print("Failed to send email")

# Close the socket
clientSocket.close()
